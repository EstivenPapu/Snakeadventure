
package paquete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class Conexion {
     private Connection conexion;
    private static final String URL = "jdbc:sqlite:C:\\Users\\Windows 10 Pro\\Documents\\NetBeansProjects\\snake11\\src\\main\\java\\basededatos\\puntuacion.db";

        public static void main(String[] args) {
         Conexion conexion = new Conexion();
        
       
         conexion.cerrarConeccion();
    }
    
        
        
      public Conexion() {
        try {
            Class.forName("org.sqlite.JDBC");
            conexion = DriverManager.getConnection(URL);
            System.out.println("Conexión a la base de datos establecida.");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

   public void agregarPuntuacion(String jugador, int puntos) {
    try {
        String query = "INSERT INTO score (jugador, puntos) VALUES (?, ?)";
        PreparedStatement preparedStatement = conexion.prepareStatement(query);
        preparedStatement.setString(1, jugador);
        preparedStatement.setInt(2, puntos);
        preparedStatement.executeUpdate();
        System.out.println("Puntuación agregada correctamente.");
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    public List<Score> obtenerDatos() {
        List<Score> puntuaciones = new ArrayList<>();
        try {
            String query = "SELECT jugador, puntos FROM score";
            PreparedStatement preparedStatement = conexion.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String jugador = resultSet.getString("jugador");
                int puntos = resultSet.getInt("puntos");
                Score puntuacion = new Score(jugador, puntos);
                puntuaciones.add(puntuacion);
            }

            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return puntuaciones;
    }

   public void eliminarTodo() {
    try {
        String query = "DELETE FROM score";
        PreparedStatement preparedStatement = conexion.prepareStatement(query);
        preparedStatement.executeUpdate();
        System.out.println("Todos los datos han sido eliminados correctamente.");
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    public void cerrarConeccion(){
      try {
            if (conexion != null) {
                conexion.close();
                System.out.println("Conexión a la base de datos cerrada.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

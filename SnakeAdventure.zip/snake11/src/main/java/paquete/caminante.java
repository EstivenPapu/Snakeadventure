
package paquete;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import paquete.panelsnake;

public class caminante implements Runnable {

    private panelsnake panel;
    private boolean estado = true;

    public caminante(panelsnake panel) {
        this.panel = panel;
    }

    @Override
    public void run() {
        while (estado) {
           
            try {
                
                panel.avanzar();
                panel.actualizarScore(panel.getSnake().size() - 2); // Actualizar el score en el panel
                panel.repaint();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(caminante.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (IOException ex) {
                Logger.getLogger(caminante.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void parar() {
        this.estado = false;
    }
}
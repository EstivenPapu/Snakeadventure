
package paquete;



import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.IOException;
import javax.sound.sampled.*;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import paquete.caminante;
import paquete.Sonido;


public final class panelsnake extends JPanel {
    
    
 
    Color colosnake = new Color(135, 206, 235); // Azul cielo
    boolean existe = false;
    Color colocomida = Color.red;
    int tammax, tam, can, res;
    List<int[]> snake = new ArrayList<>();
    int[] comida = new int[2];
    String direccion = "de";
    String direccionproxima = "de";
    private int score;
    Conexion conexion;
    private vista ventana;
    Thread hilo;
    caminante camino;

    
    
    public panelsnake(int tammax, int can, vista ventana) {
        this.tammax = tammax;
        this.can = can;
        this.tam = tammax / can;
        this.res = tammax % can;
        int[] a = {can / 2 - 1, can / 2 - 1};
        int[] b = {can / 2, can / 2 - 1};
        snake.add(a);
        snake.add(b);
        generarComida();
 
        camino = new caminante(this);
        hilo = new Thread(camino);
        hilo.start();
        
        this.ventana = ventana;
       
    }
    
    
 
    
    
    public void actualizarScore(int score) {
    this.score = score;
    
  
}
    
    
public List<int[]> getSnake() {
        return snake;
    }


   @Override
public void paint(Graphics pintor) {
    super.paint(pintor);
    pintor.setColor(colosnake);

    
     
    
    // PINTAR SERPIENTE
    for (int i = snake.size() - 1; i >= 0; i--) {
        int[] segmento = snake.get(i);
        int x = res / 2 + segmento[0] * tam;
        int y = res / 2 + segmento[1] * tam;
    
        // Calcular los bordes redondeados del segmento de la serpiente
        int bordeRedondeado = tam / 2;

        // Dibujar el segmento de la serpiente con bordes redondeados
        pintor.setColor(colosnake);
           pintor.fillRoundRect(x, y, tam, tam, bordeRedondeado, bordeRedondeado);

           
           
           
           
      
        //13 = tam
        // Si es el último segmento, dibujar los ojos 
        if (i == snake.size() - 1) {
            int ojoSize = 20 / 3;
            int ojoOffset = 10 / 11;

            // Dibujar ojo izquierdo
            pintor.setColor(Color.BLACK);
            pintor.fillOval(x + ojoOffset, y + ojoOffset, ojoSize, ojoSize);

            // Dibujar ojo derecho
            pintor.fillOval(x + tam - ojoOffset - ojoSize, y + ojoOffset, ojoSize, ojoSize);

          
        }
     

        // PINTAR COMIDA
        pintor.setColor(colocomida);
        pintor.fillOval(res / 2 + comida[0] * tam, res / 2 + comida[1] * tam, tam - 1, tam - 1);

        // Pintar score
        pintor.setColor(Color.BLACK);
        pintor.setFont(new Font("Arial", Font.BOLD, 20));
        pintor.drawString("Score: " + score, 10, 30);
    }
}
    

    public void avanzar() throws IOException {
        igualarDirecciones();
        int[] ultimo = snake.get(snake.size() - 1);
        int agregarx = 0;
        int agregary = 0;
        
          // Obtener la posición de la cabeza de la serpiente
    int[] cabeza = snake.get(snake.size() - 1);
    int x = cabeza[0];
    int y = cabeza[1];

        switch (direccion) {
            case "de":
                agregarx = 1;
                break;
            case "iz":
                agregarx = -1;
                break;
            case "ar":
                agregary = -1;
                break;
            case "ab":
                agregary = 1;
                break;
        }
        

        int[] nuevo = {Math.floorMod(ultimo[0] + agregarx, can), Math.floorMod(ultimo[1] + agregary, can)};

        for (int i = 0; i < snake.size(); i++) {
            if (nuevo[0] == snake.get(i)[0] && nuevo[1] == snake.get(i)[1]) {
                existe = true;
                break;
            }
           

        
            }
       if (existe) {
            Sonido.playSound("C:\\Users\\Windows 10 Pro\\Documents\\NetBeansProjects\\snake11\\src\\main\\java\\sonido\\gameover.mp3");
            int puntos = score;
            String nombre = mostrarCuadroDialogoNombre();
        
            
            if (nombre != null && !nombre.isEmpty()) {
                conexion = new Conexion();
                conexion.agregarPuntuacion(nombre, puntos);
                conexion.cerrarConeccion();
            }
            
                this.setVisible(false);
                ventana.cerrarventana();
                panelfondo pa = new panelfondo();
                pa.setVisible(false);
                Puntuacion puntuacion = new Puntuacion();
                puntuacion.setVisible(true);
                camino.parar();
           
            


        } else {
            if (nuevo[0] == comida[0] && nuevo[1] == comida[1]) {
                snake.add(nuevo);
                
            
                generarComida();
               
               
            } else {
                snake.add(nuevo);
                snake.remove(0);
            }
        }

        repaint();
    }
 private String mostrarCuadroDialogoNombre() {
        JTextField textField = new JTextField(15);
        textField.setFont(new Font("Arial", Font.PLAIN, 20));

        Object[] message = {
                "¡Has perdido! Ingresa tu nombre:", textField
        };

        int option = JOptionPane.showOptionDialog(null, message, "Game Over",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, null, null);

        // Si el usuario hizo clic en "OK" (en lugar de "Cancelar" o cerrar el cuadro de diálogo)
        if (option == JOptionPane.OK_OPTION) {
            return textField.getText();
        }

        return null; // Retorna null si el usuario hace clic en "Cancelar" o cierra el cuadro de diálogo
    }
    public void generarComida() {
        boolean serpiente = true;
        int x = 0, y = 0;
        while (serpiente) {
            serpiente = false;
            x = (int) (Math.random() * can);
            y = (int) (Math.random() * can);
            for (int[] par : snake) {
                if (par[0] == x && par[1] == y) {
                    serpiente = true;
                }
            }
        }
        comida[0] = x;
        comida[1] = y;
    }

    public void cambiardireccion(String dir){
if((this.direccion.equals("de") || this.direccion.equals("iz")) && (dir.equals("ar") || dir.equals("ab"))){
     this.direccionproxima = dir;
}
   if((this.direccion.equals("ar") || this.direccion.equals("ab")) && (dir.equals("de") || dir.equals("iz"))){
     this.direccionproxima = dir;
}    
   }

    private void igualarDirecciones() {
        direccion = direccionproxima;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

  
    
   
}





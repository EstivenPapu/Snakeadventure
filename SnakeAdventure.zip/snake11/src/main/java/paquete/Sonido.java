package paquete;

import javazoom.jl.player.Player;

import java.io.FileInputStream;

public class Sonido {
   public static void playSound(String filePath) {
        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            Player player = new Player(fileInputStream);
            player.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        String audioFilePath = "ruta/del/archivo.mp3"; // Cambia esto por la ruta de tu archivo MP3
        playSound(audioFilePath);
    }
}

